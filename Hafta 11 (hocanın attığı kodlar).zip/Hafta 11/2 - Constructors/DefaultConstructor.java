class A
{
    int i;
    float f;
    boolean b;
    double d;
    long l;
    char c;
    String s;
    short st;
    byte bt;
}
class DefaultConstructor {
    public static void main(String[] args) {
        A obj=new A();
        System.out.println(obj.i);
        System.out.println(obj.f);
        System.out.println(obj.b);
        System.out.println(obj.d);
        System.out.println(obj.l);
        System.out.println(obj.c);
        System.out.println(obj.s);
        System.out.println(obj.st);
        System.out.println(obj.bt);

    }
    
}